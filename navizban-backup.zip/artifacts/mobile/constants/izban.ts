import { IZBAN_ROUTE_COORDS } from "./route";
import {
  IZBAN_STATIONS,
  clampRouteMinuteForJourney,
  getCumulativeMinutes,
  getDirectionBetweenStations,
  getEstimatedMinutes,
  getNearestStation,
  getSignedRouteMinute,
  haversineKm,
  type Station,
  type TrainDirection,
} from "@workspace/navizban-core";

export {
  IZBAN_STATIONS,
  clampRouteMinuteForJourney,
  getCumulativeMinutes,
  getDirectionBetweenStations,
  getEstimatedMinutes,
  getNearestStation,
  getSignedRouteMinute,
  haversineKm,
  type Station,
  type TrainDirection,
} from "@workspace/navizban-core";

export function isNearRail(lat: number, lon: number, thresholdKm = 0.5): boolean {
  for (let i = 0; i < IZBAN_ROUTE_COORDS.length; i += 4) {
    const pt = IZBAN_ROUTE_COORDS[i];
    const d = haversineKm(lat, lon, pt.latitude, pt.longitude);
    if (d <= thresholdKm) return true;
  }
  return false;
}

export function findNearestRouteIndex(lat: number, lon: number): number {
  let bestIdx = 0;
  let bestDist = Infinity;
  for (let i = 0; i < IZBAN_ROUTE_COORDS.length; i++) {
    const pt = IZBAN_ROUTE_COORDS[i];
    const d = haversineKm(lat, lon, pt.latitude, pt.longitude);
    if (d < bestDist) {
      bestDist = d;
      bestIdx = i;
    }
  }
  return bestIdx;
}

let _stationRouteIndices: number[] | null = null;
function getStationRouteIndices(): number[] {
  if (_stationRouteIndices) return _stationRouteIndices;
  _stationRouteIndices = IZBAN_STATIONS.map(s =>
    findNearestRouteIndex(s.latitude, s.longitude)
  );
  return _stationRouteIndices;
}

export function getEffectiveStartMinutes(
  userLat: number,
  userLon: number,
  boardingStation: Station,
  destinationStation: Station
): number {
  const boardingIdx = IZBAN_STATIONS.findIndex(s => s.id === boardingStation.id);
  const destIdx = IZBAN_STATIONS.findIndex(s => s.id === destinationStation.id);
  if (boardingIdx === -1 || destIdx === -1 || boardingIdx === destIdx) return 0;

  const stRouteIndices = getStationRouteIndices();
  const boardingRouteIdx = stRouteIndices[boardingIdx];
  const destRouteIdx = stRouteIndices[destIdx];
  const userRouteIdx = findNearestRouteIndex(userLat, userLon);

  const routeMin = Math.min(boardingRouteIdx, destRouteIdx);
  const routeMax = Math.max(boardingRouteIdx, destRouteIdx);

  if (userRouteIdx < routeMin || userRouteIdx > routeMax) return 0;

  const stMin = Math.min(boardingIdx, destIdx);
  const stMax = Math.max(boardingIdx, destIdx);

  const goingNorth = boardingIdx > destIdx;

  let elapsed = 0;
  for (let i = stMin; i < stMax; i++) {
    const segStart = stRouteIndices[i];
    const segEnd = stRouteIndices[i + 1];
    const segMin = Math.min(segStart, segEnd);
    const segMax = Math.max(segStart, segEnd);

    if (userRouteIdx >= segMin && userRouteIdx <= segMax) {
      const segLen = segMax - segMin;
      if (segLen === 0) { elapsed += IZBAN_STATIONS[i].timeToNext; break; }
      const fraction = (userRouteIdx - segMin) / segLen;
      elapsed += fraction * IZBAN_STATIONS[i].timeToNext;
      break;
    } else if (userRouteIdx > segMax) {
      elapsed += IZBAN_STATIONS[i].timeToNext;
    } else {
      break;
    }
  }

  if (goingNorth) {
    const totalJourneyMinutes = getEstimatedMinutes(boardingStation, destinationStation);
    return Math.max(0, Math.min(totalJourneyMinutes - elapsed, totalJourneyMinutes));
  }
  return Math.max(0, elapsed);
}

export function getPositionOnRoute(userLat: number, userLon: number): { latitude: number; longitude: number } {
  const idx = findNearestRouteIndex(userLat, userLon);
  const pt = IZBAN_ROUTE_COORDS[idx];
  return { latitude: pt.latitude, longitude: pt.longitude };
}

export function getInterpolatedPosition(
  from: Station,
  to: Station,
  progressFraction: number
): { latitude: number; longitude: number } {
  const fromRouteIdx = findNearestRouteIndex(from.latitude, from.longitude);
  const toRouteIdx = findNearestRouteIndex(to.latitude, to.longitude);

  if (fromRouteIdx === toRouteIdx) {
    return { latitude: from.latitude, longitude: from.longitude };
  }

  const clampedProgress = Math.max(0, Math.min(1, progressFraction));
  const targetIdx = fromRouteIdx + (toRouteIdx - fromRouteIdx) * clampedProgress;

  const N = IZBAN_ROUTE_COORDS.length - 1;
  const lowerIdx = Math.max(0, Math.min(Math.floor(targetIdx), N));
  const upperIdx = Math.max(0, Math.min(Math.ceil(targetIdx), N));
  const frac = targetIdx - Math.floor(targetIdx);

  const lower = IZBAN_ROUTE_COORDS[lowerIdx];
  const upper = IZBAN_ROUTE_COORDS[upperIdx];

  if (!lower || !upper) return { latitude: from.latitude, longitude: from.longitude };

  return {
    latitude: lower.latitude + (upper.latitude - lower.latitude) * frac,
    longitude: lower.longitude + (upper.longitude - lower.longitude) * frac,
  };
}
