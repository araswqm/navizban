import React from "react";
import { Platform, View } from "react-native";
import { SvgXml } from "react-native-svg";
import { LOGO_SVG } from "@/constants/logo-svg";

const ASPECT = 2426 / 435;

interface NavizbanLogoProps {
  height?: number;
}

export function NavizbanLogo({ height = 22 }: NavizbanLogoProps) {
  const width = Math.round(ASPECT * height);

  if (Platform.OS === "web") {
    return (
      <View
        style={{
          width,
          height,
          filter: "drop-shadow(0 0 6px rgba(16,79,165,0.55))",
        } as any}
      >
        <SvgXml xml={LOGO_SVG} width={width} height={height} />
      </View>
    );
  }

  return (
    <View
      style={{
        width,
        height,
        shadowColor: "#104fa5",
        shadowOffset: { width: 0, height: 0 },
        shadowRadius: 8,
        shadowOpacity: 0.6,
        elevation: 0,
      }}
    >
      <SvgXml xml={LOGO_SVG} width={width} height={height} />
    </View>
  );
}
