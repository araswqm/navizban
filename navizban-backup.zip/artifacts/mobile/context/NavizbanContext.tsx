import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { Platform } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Location from "expo-location";
import * as Notifications from "expo-notifications";
import {
  IZBAN_STATIONS,
  Station,
  getNearestStation,
  getEstimatedMinutes,
  getInterpolatedPosition,
  getEffectiveStartMinutes,
  getPositionOnRoute,
  getSignedRouteMinute,
  isNearRail,
} from "@/constants/izban";
import {
  SharedTrain,
  fetchSharedTrains,
  finishTrainTelemetry,
  publishTrainTelemetry,
} from "@/services/trainTelemetry";

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: false,
    shouldPlaySound: false,
    shouldSetBadge: false,
  }),
});

export type ProximityStatus = "ok" | "too_far" | "checking";
export type BoardingMode = "gps" | "manual";
export type ConsentStatus = "loading" | "pending" | "accepted";

interface TrainPosition {
  latitude: number;
  longitude: number;
}

interface NavizbanContextValue {
  userLocation: { latitude: number; longitude: number } | null;
  boardingStation: Station;
  destinationStation: Station;
  boardingMode: BoardingMode;
  setDestination: (station: Station) => void;
  setBoardingManual: (station: Station) => void;
  setBoardingGps: () => void;
  totalMinutes: number;
  remainingMinutes: number;
  elapsedSeconds: number;
  effectiveOffsetSeconds: number;
  trainPosition: TrainPosition;
  isJourneyActive: boolean;
  startJourney: () => void;
  stopJourney: () => void;
  locationPermission: "granted" | "denied" | "pending";
  isLoadingLocation: boolean;
  infoPanelVisible: boolean;
  toggleInfoPanel: () => void;
  progress: number;
  proximityStatus: ProximityStatus;
  consentStatus: ConsentStatus;
  telemetrySharingEnabled: boolean;
  acceptTerms: (shareTelemetry: boolean) => Promise<void>;
  setTelemetrySharingEnabled: (enabled: boolean) => Promise<void>;
  sharedTrains: SharedTrain[];
  selectedSharedTrain: SharedTrain | null;
  isSharedTrainLoading: boolean;
}

const NavizbanContext = createContext<NavizbanContextValue | null>(null);

const DEFAULT_BOARDING_IDX = 19;
const DEFAULT_DEST_IDX = 0;
const LOCATION_TIMEOUT_MS = 8000;
const CONSENT_STORAGE_KEY = "navizban.privacy-consent.v1";
const TELEMETRY_INTERVAL_MS = 15000;
const SHARED_TRAINS_INTERVAL_MS = 20000;

async function getCoordinatesWithTimeout(): Promise<{ latitude: number; longitude: number }> {
  if (Platform.OS === "web" && typeof navigator !== "undefined" && navigator.geolocation) {
    return new Promise((resolve, reject) => {
      navigator.geolocation.getCurrentPosition(
        pos => resolve({ latitude: pos.coords.latitude, longitude: pos.coords.longitude }),
        err => reject(err),
        { timeout: LOCATION_TIMEOUT_MS, maximumAge: 60000, enableHighAccuracy: false }
      );
    });
  }
  const loc = await Promise.race([
    Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced }),
    new Promise<never>((_, reject) =>
      setTimeout(() => reject(new Error("timeout")), LOCATION_TIMEOUT_MS)
    ),
  ]);
  return { latitude: (loc as any).coords.latitude, longitude: (loc as any).coords.longitude };
}

function createJourneyId(): string {
  const random = Math.random().toString(36).slice(2, 12);
  return `journey-${Date.now().toString(36)}-${random}`;
}

function parseStoredConsent(raw: string | null): { telemetrySharingEnabled: boolean } | null {
  if (!raw) return null;
  try {
    const parsed = JSON.parse(raw) as { acceptedAt?: string; telemetrySharingEnabled?: boolean };
    if (!parsed.acceptedAt) return null;
    return { telemetrySharingEnabled: parsed.telemetrySharingEnabled === true };
  } catch {
    return null;
  }
}

export function NavizbanProvider({ children }: { children: React.ReactNode }) {
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [boardingStation, setBoardingStation] = useState<Station>(IZBAN_STATIONS[DEFAULT_BOARDING_IDX]);
  const [destinationStation, setDestinationStation] = useState<Station>(IZBAN_STATIONS[DEFAULT_DEST_IDX]);
  const [boardingMode, setBoardingModeState] = useState<BoardingMode>("gps");
  const [totalMinutes, setTotalMinutes] = useState(0);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [effectiveOffsetSeconds, setEffectiveOffsetSeconds] = useState(0);
  const [trainPosition, setTrainPosition] = useState<TrainPosition>({
    latitude: IZBAN_STATIONS[DEFAULT_BOARDING_IDX].latitude,
    longitude: IZBAN_STATIONS[DEFAULT_BOARDING_IDX].longitude,
  });
  const [isJourneyActive, setIsJourneyActive] = useState(false);
  const [locationPermission, setLocationPermission] = useState<"granted" | "denied" | "pending">("pending");
  const [isLoadingLocation, setIsLoadingLocation] = useState(true);
  const [infoPanelVisible, setInfoPanelVisible] = useState(true);
  const [proximityStatus, setProximityStatus] = useState<ProximityStatus>("checking");
  const [consentStatus, setConsentStatus] = useState<ConsentStatus>("loading");
  const [telemetrySharingEnabledState, setTelemetrySharingEnabledState] = useState(false);
  const [sharedTrains, setSharedTrains] = useState<SharedTrain[]>([]);
  const [isSharedTrainLoading, setIsSharedTrainLoading] = useState(false);

  const journeyTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const locationTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const telemetryTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const sharedTrainsTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const journeyStartTimeRef = useRef<number>(0);
  const lastGpsMinuteRef = useRef<number>(0);
  const notifIdRef = useRef<string | null>(null);
  const journeyIdRef = useRef<string | null>(null);
  const boardingRef = useRef(boardingStation);
  const destRef = useRef(destinationStation);
  const totalMinutesRef = useRef(totalMinutes);
  const userLocationRef = useRef(userLocation);
  const boardingModeRef = useRef(boardingMode);
  const effectiveOffsetRef = useRef(effectiveOffsetSeconds);
  const elapsedSecondsRef = useRef(elapsedSeconds);
  const trainPositionRef = useRef(trainPosition);
  const isJourneyActiveRef = useRef(isJourneyActive);
  const consentStatusRef = useRef(consentStatus);
  const telemetrySharingRef = useRef(telemetrySharingEnabledState);

  useEffect(() => { boardingRef.current = boardingStation; }, [boardingStation]);
  useEffect(() => { destRef.current = destinationStation; }, [destinationStation]);
  useEffect(() => { totalMinutesRef.current = totalMinutes; }, [totalMinutes]);
  useEffect(() => { userLocationRef.current = userLocation; }, [userLocation]);
  useEffect(() => { boardingModeRef.current = boardingMode; }, [boardingMode]);
  useEffect(() => { effectiveOffsetRef.current = effectiveOffsetSeconds; }, [effectiveOffsetSeconds]);
  useEffect(() => { elapsedSecondsRef.current = elapsedSeconds; }, [elapsedSeconds]);
  useEffect(() => { trainPositionRef.current = trainPosition; }, [trainPosition]);
  useEffect(() => { isJourneyActiveRef.current = isJourneyActive; }, [isJourneyActive]);
  useEffect(() => { consentStatusRef.current = consentStatus; }, [consentStatus]);
  useEffect(() => { telemetrySharingRef.current = telemetrySharingEnabledState; }, [telemetrySharingEnabledState]);

  useEffect(() => {
    let mounted = true;
    AsyncStorage.getItem(CONSENT_STORAGE_KEY)
      .then((raw) => {
        if (!mounted) return;
        const stored = parseStoredConsent(raw);
        if (!stored) {
          setConsentStatus("pending");
          return;
        }
        setTelemetrySharingEnabledState(stored.telemetrySharingEnabled);
        setConsentStatus("accepted");
      })
      .catch(() => {
        if (mounted) setConsentStatus("pending");
      });
    return () => {
      mounted = false;
    };
  }, []);

  const acceptTerms = useCallback(async (shareTelemetry: boolean) => {
    const payload = {
      acceptedAt: new Date().toISOString(),
      telemetrySharingEnabled: shareTelemetry,
      version: "1.2-beta",
    };
    setTelemetrySharingEnabledState(shareTelemetry);
    setConsentStatus("accepted");
    try {
      await AsyncStorage.setItem(CONSENT_STORAGE_KEY, JSON.stringify(payload));
    } catch {}
  }, []);

  const setTelemetrySharingEnabled = useCallback(async (enabled: boolean) => {
    setTelemetrySharingEnabledState(enabled);
    if (consentStatusRef.current !== "accepted") return;
    const payload = {
      acceptedAt: new Date().toISOString(),
      telemetrySharingEnabled: enabled,
      version: "1.2-beta",
    };
    try {
      await AsyncStorage.setItem(CONSENT_STORAGE_KEY, JSON.stringify(payload));
    } catch {}
  }, []);

  const applyGpsLocation = useCallback((coords: { latitude: number; longitude: number }, dest: Station) => {
    setUserLocation(coords);
    const nearest = getNearestStation(coords.latitude, coords.longitude);
    setBoardingStation(nearest);
    const routePos = getPositionOnRoute(coords.latitude, coords.longitude);
    setTrainPosition(routePos);
    const nearRail = isNearRail(coords.latitude, coords.longitude, 0.5);
    setProximityStatus(nearRail ? "ok" : "too_far");
    const offset = getEffectiveStartMinutes(coords.latitude, coords.longitude, nearest, dest);
    setEffectiveOffsetSeconds(offset * 60);
  }, []);

  const requestLocation = useCallback(async () => {
    setIsLoadingLocation(true);
    try {
      if (Platform.OS === "web") {
        setLocationPermission("granted");
        try {
          const coords = await getCoordinatesWithTimeout();
          applyGpsLocation(coords, destRef.current);
        } catch {
          setProximityStatus("ok");
        }
      } else {
        const { status } = await Location.requestForegroundPermissionsAsync();
        if (status === "granted") {
          setLocationPermission("granted");
          try {
            const coords = await getCoordinatesWithTimeout();
            applyGpsLocation(coords, destRef.current);
          } catch {
            setProximityStatus("ok");
          }
        } else {
          setLocationPermission("denied");
          setProximityStatus("too_far");
        }
      }
    } catch {
      setLocationPermission("denied");
      setProximityStatus("too_far");
    } finally {
      setIsLoadingLocation(false);
    }
  }, [applyGpsLocation]);

  const requestNotificationPermission = useCallback(async () => {
    try { await Notifications.requestPermissionsAsync(); } catch {}
  }, []);

  useEffect(() => {
    if (consentStatus !== "accepted") return;
    requestLocation();
    requestNotificationPermission();
  }, [consentStatus, requestLocation, requestNotificationPermission]);

  useEffect(() => {
    const mins = getEstimatedMinutes(boardingStation, destinationStation);
    setTotalMinutes(mins);
    if (!isJourneyActive) {
      setElapsedSeconds(0);
      if (boardingMode === "gps" && userLocation) {
        const routePos = getPositionOnRoute(userLocation.latitude, userLocation.longitude);
        setTrainPosition(routePos);
        const offset = getEffectiveStartMinutes(userLocation.latitude, userLocation.longitude, boardingStation, destinationStation);
        setEffectiveOffsetSeconds(offset * 60);
      } else {
        setTrainPosition({ latitude: boardingStation.latitude, longitude: boardingStation.longitude });
        setEffectiveOffsetSeconds(0);
      }
    }
  }, [boardingStation.id, destinationStation.id]);

  const scheduleJourneyNotification = useCallback(async (remainMins: number, prog: number) => {
    try {
      if (notifIdRef.current) {
        await Notifications.dismissNotificationAsync(notifIdRef.current);
      }
      const id = await Notifications.scheduleNotificationAsync({
        content: {
          title: `🚂 ${boardingRef.current.name} → ${destRef.current.name}`,
          body: `${Math.ceil(remainMins)} dk kalan · %${Math.round(prog * 100)} tamamlandı`,
          data: { type: "journey" },
        } as Notifications.NotificationContentInput,
        trigger: null,
      });
      notifIdRef.current = id;
    } catch {}
  }, []);

  const cancelJourneyNotification = useCallback(async () => {
    try {
      if (notifIdRef.current) {
        await Notifications.dismissNotificationAsync(notifIdRef.current);
        notifIdRef.current = null;
      }
      await Notifications.dismissAllNotificationsAsync();
    } catch {}
  }, []);

  const publishCurrentTelemetry = useCallback(() => {
    if (
      consentStatusRef.current !== "accepted" ||
      !telemetrySharingRef.current ||
      !journeyIdRef.current
    ) {
      return;
    }

    const boarding = boardingRef.current;
    const destination = destRef.current;
    const total = totalMinutesRef.current;
    if (boarding.id === destination.id || total <= 0) return;

    const elapsedMinutes = Math.max(0, Math.min(elapsedSecondsRef.current / 60, total));
    const routeMinute = getSignedRouteMinute(boarding.id, destination.id, elapsedMinutes);
    const position = trainPositionRef.current;

    void publishTrainTelemetry({
      journeyId: journeyIdRef.current,
      originStationId: boarding.id,
      destinationStationId: destination.id,
      routeMinute,
      position,
    });
  }, []);

  const finishSharedJourney = useCallback(() => {
    const journeyId = journeyIdRef.current;
    if (!journeyId) return;
    journeyIdRef.current = null;
    void finishTrainTelemetry(journeyId);
  }, []);

  const stopJourney = useCallback(() => {
    setIsJourneyActive(false);
    if (journeyTimerRef.current) {
      clearInterval(journeyTimerRef.current);
      journeyTimerRef.current = null;
    }
    if (telemetryTimerRef.current) {
      clearInterval(telemetryTimerRef.current);
      telemetryTimerRef.current = null;
    }
    finishSharedJourney();
    cancelJourneyNotification();
  }, [cancelJourneyNotification, finishSharedJourney]);

  const startJourney = useCallback(() => {
    if (boardingStation.id === destinationStation.id) return;
    if (boardingMode === "manual") return;
    if (proximityStatus === "too_far") return;
    const total = getEstimatedMinutes(boardingStation, destinationStation);
    if (total <= 0) return;

    const startOffset = effectiveOffsetRef.current;
    setElapsedSeconds(startOffset);
    journeyStartTimeRef.current = Date.now() - startOffset * 1000;
    lastGpsMinuteRef.current = Math.floor(startOffset / 60);
    journeyIdRef.current = createJourneyId();
    setIsJourneyActive(true);
    scheduleJourneyNotification(total - startOffset / 60, startOffset / (total * 60));
  }, [boardingStation, destinationStation, boardingMode, proximityStatus, scheduleJourneyNotification]);

  useEffect(() => {
    if (!isJourneyActive) return;
    const total = totalMinutesRef.current;

    journeyTimerRef.current = setInterval(() => {
      const elapsed = (Date.now() - journeyStartTimeRef.current) / 1000;
      const elapsedMin = elapsed / 60;
      const prog = Math.min(elapsedMin / total, 1);

      setElapsedSeconds(elapsed);

      const pos = getInterpolatedPosition(boardingRef.current, destRef.current, prog);
      setTrainPosition(pos);

      const minuteMark = Math.floor(elapsedMin);
      if (minuteMark > lastGpsMinuteRef.current) {
        lastGpsMinuteRef.current = minuteMark;
        const remaining = Math.max(total - elapsedMin, 0);
        scheduleJourneyNotification(remaining, prog);
      }

      if (prog >= 1) {
        setTrainPosition({ latitude: destRef.current.latitude, longitude: destRef.current.longitude });
        setIsJourneyActive(false);
        finishSharedJourney();
        cancelJourneyNotification();
        clearInterval(journeyTimerRef.current!);
        journeyTimerRef.current = null;
      }
    }, 1000);

    return () => {
      if (journeyTimerRef.current) clearInterval(journeyTimerRef.current);
    };
  }, [isJourneyActive, scheduleJourneyNotification, cancelJourneyNotification, finishSharedJourney]);

  useEffect(() => {
    if (
      !isJourneyActive ||
      consentStatus !== "accepted" ||
      !telemetrySharingEnabledState
    ) {
      return;
    }

    publishCurrentTelemetry();
    telemetryTimerRef.current = setInterval(
      publishCurrentTelemetry,
      TELEMETRY_INTERVAL_MS,
    );

    return () => {
      if (telemetryTimerRef.current) {
        clearInterval(telemetryTimerRef.current);
        telemetryTimerRef.current = null;
      }
    };
  }, [isJourneyActive, consentStatus, telemetrySharingEnabledState, publishCurrentTelemetry]);

  useEffect(() => {
    if (consentStatus !== "accepted") return;
    if (locationPermission !== "granted") return;

    locationTimerRef.current = setInterval(async () => {
      try {
        const coords = await getCoordinatesWithTimeout();
        setUserLocation(coords);
        if (!isJourneyActive && boardingModeRef.current === "gps") {
          const nearest = getNearestStation(coords.latitude, coords.longitude);
          setBoardingStation(nearest);
          const routePos = getPositionOnRoute(coords.latitude, coords.longitude);
          setTrainPosition(routePos);
          const nearRail = isNearRail(coords.latitude, coords.longitude, 0.5);
          setProximityStatus(nearRail ? "ok" : "too_far");
          const offset = getEffectiveStartMinutes(coords.latitude, coords.longitude, nearest, destRef.current);
          setEffectiveOffsetSeconds(offset * 60);
        }
      } catch {}
    }, 60000);

    return () => {
      if (locationTimerRef.current) clearInterval(locationTimerRef.current);
    };
  }, [consentStatus, locationPermission, isJourneyActive]);

  const refreshSharedTrains = useCallback(async () => {
    if (consentStatusRef.current !== "accepted") return;
    setIsSharedTrainLoading(true);
    const trains = await fetchSharedTrains(
      boardingRef.current.id,
      destRef.current.id,
    );
    setSharedTrains(trains);
    const firstTrain = trains[0];
    if (!isJourneyActiveRef.current && firstTrain) {
      setTrainPosition(firstTrain.position);
    }
    setIsSharedTrainLoading(false);
  }, []);

  useEffect(() => {
    if (sharedTrainsTimerRef.current) {
      clearInterval(sharedTrainsTimerRef.current);
      sharedTrainsTimerRef.current = null;
    }

    if (consentStatus !== "accepted") return;

    refreshSharedTrains();
    sharedTrainsTimerRef.current = setInterval(
      refreshSharedTrains,
      SHARED_TRAINS_INTERVAL_MS,
    );

    return () => {
      if (sharedTrainsTimerRef.current) {
        clearInterval(sharedTrainsTimerRef.current);
        sharedTrainsTimerRef.current = null;
      }
    };
  }, [consentStatus, boardingStation.id, destinationStation.id, refreshSharedTrains]);

  const setDestination = useCallback((station: Station) => {
    setDestinationStation(station);
    stopJourney();
    setElapsedSeconds(0);
  }, [stopJourney]);

  const setBoardingManual = useCallback((station: Station) => {
    setBoardingModeState("manual");
    setBoardingStation(station);
    setTrainPosition({ latitude: station.latitude, longitude: station.longitude });
    setEffectiveOffsetSeconds(0);
    setElapsedSeconds(0);
    stopJourney();
  }, [stopJourney]);

  const setBoardingGps = useCallback(() => {
    setBoardingModeState("gps");
    const loc = userLocationRef.current;
    if (loc) {
      const nearest = getNearestStation(loc.latitude, loc.longitude);
      setBoardingStation(nearest);
      const routePos = getPositionOnRoute(loc.latitude, loc.longitude);
      setTrainPosition(routePos);
      const offset = getEffectiveStartMinutes(loc.latitude, loc.longitude, nearest, destRef.current);
      setEffectiveOffsetSeconds(offset * 60);
    }
    setElapsedSeconds(0);
    stopJourney();
  }, [stopJourney]);

  const toggleInfoPanel = useCallback(() => {
    setInfoPanelVisible(prev => !prev);
  }, []);

  const elapsedMinutes = elapsedSeconds / 60;
  const remainingMinutes = isJourneyActive
    ? Math.max(totalMinutes - elapsedMinutes, 0)
    : Math.max(totalMinutes - effectiveOffsetSeconds / 60, 0);

  const progress = totalMinutes > 0
    ? Math.min(
        isJourneyActive
          ? elapsedSeconds / (totalMinutes * 60)
          : effectiveOffsetSeconds / (totalMinutes * 60),
        1
      )
    : 0;

  const value = useMemo<NavizbanContextValue>(() => ({
    userLocation,
    boardingStation,
    destinationStation,
    boardingMode,
    setDestination,
    setBoardingManual,
    setBoardingGps,
    totalMinutes,
    remainingMinutes,
    elapsedSeconds,
    effectiveOffsetSeconds,
    trainPosition,
    isJourneyActive,
    startJourney,
    stopJourney,
    locationPermission,
    isLoadingLocation,
    infoPanelVisible,
    toggleInfoPanel,
    progress,
    proximityStatus,
  }), [
    userLocation, boardingStation, destinationStation, boardingMode,
    setDestination, setBoardingManual, setBoardingGps,
    totalMinutes, remainingMinutes, elapsedSeconds, effectiveOffsetSeconds,
    trainPosition, isJourneyActive, startJourney, stopJourney,
    locationPermission, isLoadingLocation, infoPanelVisible, toggleInfoPanel,
    progress, proximityStatus,
  ]);

  return (
    <NavizbanContext.Provider value={value}>
      {children}
    </NavizbanContext.Provider>
  );
}

export function useNavizban() {
  const ctx = useContext(NavizbanContext);
  if (!ctx) throw new Error("useNavizban must be inside NavizbanProvider");
  return ctx;
}
