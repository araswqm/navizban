import { Platform } from "react-native";

declare const process: { env: Record<string, string | undefined> };

export interface SharedTrain {
  id: string;
  direction: "northbound" | "southbound";
  originStationId: string;
  destinationStationId: string;
  currentStationId: string;
  position: {
    latitude: number;
    longitude: number;
  };
  routeMinute: number;
  etaToStationMinutes: number | null;
  etaStationToDestinationMinutes: number | null;
  etaToFinalMinutes: number;
  observedAgoSeconds: number;
  confidence: "live" | "recent";
}

interface SharedTrainResponse {
  trains: SharedTrain[];
}

interface TelemetryPayload {
  journeyId: string;
  originStationId: string;
  destinationStationId: string;
  routeMinute: number;
  position: {
    latitude: number;
    longitude: number;
  };
}

const DEFAULT_API_URL = "https://navizban.xyz/api";

function normalizeBaseUrl(url: string): string {
  return url.replace(/\/+$/, "");
}

export function getApiBaseUrl(): string {
  const configured = process.env.EXPO_PUBLIC_NAVIZBAN_API_URL;
  if (configured && configured.trim().length > 0) {
    return normalizeBaseUrl(configured.trim());
  }

  if (Platform.OS === "web" && typeof window !== "undefined") {
    return `${window.location.origin.replace(/\/+$/, "")}/api`;
  }

  return DEFAULT_API_URL;
}

async function request(path: string, init?: RequestInit): Promise<Response> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 7000);
  try {
    return await fetch(`${getApiBaseUrl()}${path}`, {
      ...init,
      signal: controller.signal,
      headers: {
        "content-type": "application/json",
        ...(init?.headers ?? {}),
      },
    });
  } finally {
    clearTimeout(timeout);
  }
}

export async function publishTrainTelemetry(payload: TelemetryPayload): Promise<boolean> {
  try {
    const response = await request("/trains/telemetry", {
      method: "POST",
      body: JSON.stringify(payload),
    });
    return response.ok;
  } catch {
    return false;
  }
}

export async function finishTrainTelemetry(journeyId: string): Promise<void> {
  try {
    await request("/trains/telemetry", {
      method: "POST",
      body: JSON.stringify({ journeyId, active: false }),
    });
  } catch {}
}

export async function fetchSharedTrains(
  stationId: string,
  destinationStationId?: string,
): Promise<SharedTrain[]> {
  try {
    const query = new URLSearchParams({ stationId });
    if (destinationStationId) query.set("destinationStationId", destinationStationId);
    const response = await request(`/trains?${query.toString()}`);
    if (!response.ok) return [];
    const data = await response.json() as SharedTrainResponse;
    return Array.isArray(data.trains) ? data.trains : [];
  } catch {
    return [];
  }
}
