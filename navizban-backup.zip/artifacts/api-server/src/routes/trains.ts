import { Router, type IRouter } from "express";
import {
  IZBAN_STATIONS,
  clampRouteMinuteForJourney,
  getCumulativeMinutes,
  getDirectionBetweenStations,
  getEstimatedMinutesById,
  getStation,
  type TrainDirection,
} from "@workspace/navizban-core";

interface SnappedPosition {
  latitude: number;
  longitude: number;
}

interface TrainReport {
  journeyId: string;
  originStationId: string;
  destinationStationId: string;
  direction: TrainDirection;
  routeMinute: number;
  position: SnappedPosition;
  updatedAt: number;
}

const router: IRouter = Router();
const reports = new Map<string, TrainReport>();
const ttlSeconds = Number(process.env["NAVIZBAN_TRAIN_TTL_SECONDS"] ?? 180);
const ttlMs = Math.max(30, ttlSeconds) * 1000;
const maxActiveReports = Number(process.env["NAVIZBAN_MAX_ACTIVE_TRAINS"] ?? 500);

function getString(value: unknown): string | null {
  return typeof value === "string" && value.trim().length > 0 ? value.trim() : null;
}

function getNumber(value: unknown): number | null {
  const num = Number(value);
  return Number.isFinite(num) ? num : null;
}

function isPositionInIzmir(position: SnappedPosition): boolean {
  return (
    position.latitude >= 37.8 &&
    position.latitude <= 38.9 &&
    position.longitude >= 26.7 &&
    position.longitude <= 27.6
  );
}

function pruneReports(now = Date.now()) {
  for (const [journeyId, report] of reports) {
    if (now - report.updatedAt > ttlMs) {
      reports.delete(journeyId);
      continue;
    }

    const agedRouteMinute = getAgedRouteMinute(report, now);
    const destinationMinute = getCumulativeMinutes(report.destinationStationId);
    const passedDestination = report.direction === "southbound"
      ? agedRouteMinute > destinationMinute + 0.3
      : agedRouteMinute < destinationMinute - 0.3;

    if (passedDestination) {
      reports.delete(journeyId);
    }
  }
}

function getAgedRouteMinute(report: TrainReport, now: number): number {
  const elapsedMinutes = Math.max(0, (now - report.updatedAt) / 60000);
  const sign = report.direction === "southbound" ? 1 : -1;
  return report.routeMinute + elapsedMinutes * sign;
}

function getCurrentStationId(routeMinute: number): string {
  let bestStation = IZBAN_STATIONS[0]!;
  let bestDelta = Infinity;
  for (const station of IZBAN_STATIONS) {
    const delta = Math.abs(getCumulativeMinutes(station.id) - routeMinute);
    if (delta < bestDelta) {
      bestStation = station;
      bestDelta = delta;
    }
  }
  return bestStation.id;
}

function isStationAhead(
  direction: TrainDirection,
  currentRouteMinute: number,
  destinationRouteMinute: number,
  stationRouteMinute: number,
): boolean {
  if (direction === "southbound") {
    return currentRouteMinute <= stationRouteMinute && stationRouteMinute <= destinationRouteMinute;
  }
  return currentRouteMinute >= stationRouteMinute && stationRouteMinute >= destinationRouteMinute;
}

function getStationToDestinationMinutes(
  stationId: string,
  destinationStationId: string | null,
  trainDirection: TrainDirection,
): number | null {
  if (!destinationStationId) return null;
  if (stationId === destinationStationId) return 0;
  const stationDirection = getDirectionBetweenStations(stationId, destinationStationId);
  if (stationDirection !== trainDirection) return null;
  return getEstimatedMinutesById(stationId, destinationStationId);
}

router.get("/trains", (req, res) => {
  const now = Date.now();
  pruneReports(now);

  const stationId = getString(req.query["stationId"]);
  const destinationStationId = getString(req.query["destinationStationId"]);
  const station = stationId ? getStation(stationId) : null;

  if (stationId && !station) {
    res.status(400).json({ error: "Unknown stationId" });
    return;
  }

  if (destinationStationId && !getStation(destinationStationId)) {
    res.status(400).json({ error: "Unknown destinationStationId" });
    return;
  }

  const stationRouteMinute = station ? getCumulativeMinutes(station.id) : null;

  const trains = Array.from(reports.values())
    .map((report) => {
      const agedRouteMinute = getAgedRouteMinute(report, now);
      const currentRouteMinute = clampRouteMinuteForJourney(
        agedRouteMinute,
        report.originStationId,
        report.destinationStationId,
      );
      const destinationRouteMinute = getCumulativeMinutes(report.destinationStationId);

      if (
        station &&
        stationRouteMinute !== null &&
        !isStationAhead(report.direction, currentRouteMinute, destinationRouteMinute, stationRouteMinute)
      ) {
        return null;
      }

      const etaToStationMinutes = station && stationRouteMinute !== null
        ? Math.max(0, Math.abs(stationRouteMinute - currentRouteMinute))
        : null;
      const etaStationToDestinationMinutes = station
        ? getStationToDestinationMinutes(station.id, destinationStationId, report.direction)
        : null;
      const observedAgoSeconds = Math.max(0, Math.round((now - report.updatedAt) / 1000));

      return {
        id: report.journeyId.slice(0, 12),
        direction: report.direction,
        originStationId: report.originStationId,
        destinationStationId: report.destinationStationId,
        currentStationId: getCurrentStationId(currentRouteMinute),
        position: report.position,
        routeMinute: Number(currentRouteMinute.toFixed(2)),
        etaToStationMinutes: etaToStationMinutes === null
          ? null
          : Number(etaToStationMinutes.toFixed(1)),
        etaStationToDestinationMinutes: etaStationToDestinationMinutes === null
          ? null
          : Number(etaStationToDestinationMinutes.toFixed(1)),
        etaToFinalMinutes: Number(Math.abs(destinationRouteMinute - currentRouteMinute).toFixed(1)),
        observedAgoSeconds,
        confidence: observedAgoSeconds <= 45 ? "live" : "recent",
      };
    })
    .filter((train): train is NonNullable<typeof train> => train !== null)
    .sort((a, b) => {
      if (a.etaToStationMinutes !== null && b.etaToStationMinutes !== null) {
        return a.etaToStationMinutes - b.etaToStationMinutes;
      }
      return a.observedAgoSeconds - b.observedAgoSeconds;
    });

  res.setHeader("cache-control", "no-store");
  res.json({
    updatedAt: new Date(now).toISOString(),
    ttlSeconds: Math.floor(ttlMs / 1000),
    trains,
  });
});

router.post("/trains/telemetry", (req, res) => {
  pruneReports();

  const body = req.body as Record<string, unknown>;
  const journeyId = getString(body["journeyId"]);

  if (!journeyId || journeyId.length > 80) {
    res.status(400).json({ error: "journeyId is required" });
    return;
  }

  if (body["active"] === false) {
    reports.delete(journeyId);
    res.json({ status: "removed" });
    return;
  }

  const originStationId = getString(body["originStationId"]);
  const destinationStationId = getString(body["destinationStationId"]);
  const routeMinute = getNumber(body["routeMinute"]);
  const rawPosition = body["position"] as Record<string, unknown> | undefined;
  const latitude = getNumber(rawPosition?.["latitude"]);
  const longitude = getNumber(rawPosition?.["longitude"]);

  if (!originStationId || !destinationStationId) {
    res.status(400).json({ error: "originStationId and destinationStationId are required" });
    return;
  }

  const direction = getDirectionBetweenStations(originStationId, destinationStationId);
  if (!direction) {
    res.status(400).json({ error: "origin/destination route is invalid" });
    return;
  }

  if (routeMinute === null || latitude === null || longitude === null) {
    res.status(400).json({ error: "routeMinute and snapped position are required" });
    return;
  }

  const position = { latitude, longitude };
  if (!isPositionInIzmir(position)) {
    res.status(400).json({ error: "position is outside supported route bounds" });
    return;
  }

  if (reports.size >= maxActiveReports && !reports.has(journeyId)) {
    const oldest = Array.from(reports.entries()).sort((a, b) => a[1].updatedAt - b[1].updatedAt)[0];
    if (oldest) reports.delete(oldest[0]);
  }

  reports.set(journeyId, {
    journeyId,
    originStationId,
    destinationStationId,
    direction,
    routeMinute: clampRouteMinuteForJourney(routeMinute, originStationId, destinationStationId),
    position,
    updatedAt: Date.now(),
  });

  res.json({
    status: "ok",
    expiresInSeconds: Math.floor(ttlMs / 1000),
  });
});

router.delete("/trains/:journeyId", (req, res) => {
  const journeyId = getString(req.params["journeyId"]);
  if (journeyId) {
    reports.delete(journeyId);
  }
  res.json({ status: "removed" });
});

export default router;
