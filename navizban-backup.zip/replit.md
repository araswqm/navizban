# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## Structure

```text
artifacts-monorepo/
├── artifacts/              # Deployable applications
│   ├── api-server/         # Express API server
│   └── mobile/             # Navizban Expo mobile app
├── lib/                    # Shared libraries
│   ├── api-spec/           # OpenAPI spec + Orval codegen config
│   ├── api-client-react/   # Generated React Query hooks
│   ├── api-zod/            # Generated Zod schemas from OpenAPI
│   └── db/                 # Drizzle ORM schema + DB connection
├── scripts/                # Utility scripts
├── pnpm-workspace.yaml     # pnpm workspace
├── tsconfig.base.json      # Shared TS options
├── tsconfig.json           # Root TS project references
└── package.json            # Root package with hoisted devDeps
```

## Mobile App: Navizban

A modern İZBAN suburban rail companion app for İzmir, built with Expo.

### Features
- **Real KML route**: 887-point İZBAN route rendered with 3-segment polyline (dim bg / active blue / passed gray)
- **GPS-based boarding**: Expo Location auto-detects nearest İZBAN station; GPS offset shifts journey start
- **Boarding mode**: GPS auto-detect OR manual station selection via boarding picker
- **Destination picker**: Search + select any of 41 İZBAN stations
- **Animated train cursor**: Pulsing blue dot follows KML route (Leaflet web / react-native-maps native)
- **Real-time simulation**: Journey timer (1s interval), progress bar, remaining time with glow
- **Persistent notifications**: Journey notifications update every minute
- **Dark/Light theme**: System default, toggle button, 300ms fade animation (ThemeContext)
- **SVG logo**: NAVIZBAN wordmark rendered via react-native-svg with blue glow
- **Google Maps / Material You aesthetic**: Dark navy bg, Google Blue #1A73E8, Google Green #34A853
- **Hideable bottom panel**: Animated slide up/down

### Key Files
- `artifacts/mobile/constants/colors.ts` — Full dark/light palettes, ColorTheme type
- `artifacts/mobile/constants/izban.ts` — 41 İZBAN stations, time calc, GPS offset, route utils
- `artifacts/mobile/constants/logo-svg.ts` — NAVIZBAN SVG string constant
- `artifacts/mobile/constants/route.ts` — 887-point KML route coordinates
- `artifacts/mobile/context/ThemeContext.tsx` — Theme context (dark/light, fade animation, useTheme hook)
- `artifacts/mobile/context/NavizbanContext.tsx` — Global state (location, boarding mode, journey, timer)
- `artifacts/mobile/components/NavizbanLogo.tsx` — SVG logo component with glow
- `artifacts/mobile/components/TrainMap.native.tsx` — Native map with 3-segment route polylines
- `artifacts/mobile/components/TrainMap.web.tsx` — Leaflet web map with 3-segment route polylines
- `artifacts/mobile/components/InfoPanel.tsx` — Bottom panel with Reanimated button color animation
- `artifacts/mobile/components/TopBar.tsx` — Header with logo, theme toggle, dual boarding/dest pickers
- `artifacts/mobile/components/StationPicker.tsx` — Station search modal (boarding + destination modes)

### Colors (Dark theme)
- Background: #0E1117 (midnight navy)
- Accent: #1A73E8 (Google Blue)
- Success: #34A853 (Google Green)
- Danger: #EA4335 (Google Red)

### Critical Notes
- `react-native-maps` pinned to 1.18.0 — do NOT upgrade
- ThemeProvider wraps NavizbanProvider in `app/_layout.tsx`
- `findNearestRouteIndex` is exported from izban.ts (used in TrainMap for segment calc)
- `boardingMode: 'gps' | 'manual'` — manual mode disables journey start

## Packages

### `artifacts/api-server` (`@workspace/api-server`)

Express 5 API server. Routes live in `src/routes/` and use `@workspace/api-zod` for validation and `@workspace/db` for persistence.

### `lib/db` (`@workspace/db`)

Database layer using Drizzle ORM with PostgreSQL.

### `lib/api-spec` (`@workspace/api-spec`)

OpenAPI 3.1 spec + Orval codegen. Run codegen: `pnpm --filter @workspace/api-spec run codegen`

### `lib/api-zod` (`@workspace/api-zod`)

Generated Zod schemas from the OpenAPI spec.

### `lib/api-client-react` (`@workspace/api-client-react`)

Generated React Query hooks and fetch client from the OpenAPI spec.
